package com.example.prjconfeitaria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
