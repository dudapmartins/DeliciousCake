import 'package:flutter/material.dart'; // Importando o pacote material, que contém os widgets do Flutter
import 'menu.dart'; // Importando o arquivo login.dart

Color mybuttonColor = Color(0xFF4D6659); // Definindo uma cor personalizada para o botão

class login extends StatelessWidget { // Classe LoginScreen que herda de StatelessWidget
  @override
  Widget build(BuildContext context) { // Método build que retorna o widget da tela de login
    return MaterialApp( // MaterialApp: Widget que define as configurações gerais do app
      home: Scaffold( // Scaffold: Widget responsável por criar um layout "padrão" para a tela
        appBar: AppBar( // AppBar: Barra localizada na parte superior da tela
          title: Text('Login'), // Título da AppBar
          backgroundColor: Color(0xFF7BA28F), // Cor de fundo da AppBar
        ),
        body: LoginBody(), // Corpo da tela, definido pelo widget LoginBody
      ),
    );
  }
}

class LoginBody extends StatelessWidget { // Classe LoginBody que herda de StatelessWidget
  TextEditingController _usernameController = TextEditingController(); // Controlador para o campo de login
  TextEditingController _passwordController = TextEditingController(); // Controlador para o campo de senha

  @override
  Widget build(BuildContext context) { // Método build que retorna o widget do corpo da tela de login
    return Container(// Container que envolve o conteúdo da tela
      decoration: BoxDecoration( // Estilização do Container
        color: Color(0xffFFAF9F), // Cor de fundo com opacidade
      ),
      child: Column( // Coluna que organiza os widgets verticalmente
        mainAxisAlignment: MainAxisAlignment.center, // Alinhamento vertical ao centro
        children: [
          Center( // Centralizar o contêiner que contém a imagem de logo
            child: Container(//contêiner que contém a imagem de logo
              width: 800, // Largura desejada para a imagem de logo
              height: 150, // Altura desejada para a imagem de logo
              decoration: BoxDecoration(
                image: DecorationImage( // Adicionando uma imagem de fundo ao Container
                  image: AssetImage('assets/chef.png'), // Caminho da imagem de logo
                  fit: BoxFit.contain, // Ajuste da imagem ao Container
                ),
              ),
            ),
          ),
          Container( // Container para os campos de entrada e botão
            padding: EdgeInsets.all(15.0), // Espaçamento interno
            decoration: BoxDecoration(
              color: Color(0xFF07BA28F), // Cor de fundo do Container
              borderRadius: BorderRadius.circular(10.0), // Bordas arredondadas
            ),
            child: Column( // Coluna que organiza os widgets verticalmente
              children: [
                TextField( // Campo de texto para o login
                  controller: _usernameController, // Controlador associado ao campo
                  decoration: InputDecoration( // Estilização do campo de texto
                    labelText: 'Login', // Rótulo do campo
                    prefixIcon: Icon(Icons.person), // Ícone prefixo
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0), // Bordas arredondadas
                    ),
                  ),
                ),
                SizedBox(height: 20.0), // Espaçamento entre os campos de texto
                TextField( // Campo de texto para a senha
                  controller: _passwordController, // Controlador associado ao campo
                  decoration: InputDecoration( // Estilização do campo de texto
                    labelText: 'Senha', // Rótulo do campo
                    prefixIcon: Icon(Icons.lock), // Ícone prefixo
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0), // Bordas arredondadas
                    ),
                  ),
                  obscureText: true, // Texto obscurecido (senha)
                ),
                SizedBox(height: 20.0), // Espaçamento entre os campos de texto e o botão
                ElevatedButton( // Botão para enviar os dados do login
                  onPressed: () {onPressed: () { // Ação ao pressionar o botão
                    Navigator.push( // Navega para a calculadora
                      context,
                      MaterialPageRoute(builder: (context) => Menu()),
                    );
                  };
                  // Simulação de verificação de login (substitua pelo seu código de verificação)
                  String username = _usernameController.text; // Obtém o valor do campo de login
                  String password = _passwordController.text; // Obtém o valor do campo de senha
                  if (username == 'deliciouscake' && password == '123456') { // Verifica as credenciais
                    Navigator.pushReplacement( // Navega para a tela inicial
                      context,
                      MaterialPageRoute(builder: (context) => Menu()),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar( // Mostra uma mensagem de erro
                      SnackBar(content: Text('Credenciais inválidas')),
                    );
                  }
                  },
                  child: const Text('Entrar'), // Texto exibido no botão
                  style: ElevatedButton.styleFrom( // Estilização do botão
                    backgroundColor: Color(0xFF4D6659),
                    textStyle: TextStyle(fontSize: 18, color: Colors.white),
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20), // Espaçamento interno
                    minimumSize: Size(100, 0), // Tamanho mínimo do botão
                    shape: RoundedRectangleBorder( // Forma do botão
                      borderRadius: BorderRadius.circular(15), // Bordas arredondadas
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}