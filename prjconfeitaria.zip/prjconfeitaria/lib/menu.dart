import 'package:flutter/material.dart'; // Importando o pacote material, que contém os widgets do Flutter
import 'cardapio.dart'; // Importando o arquivo Service_Screen.dart

class Menu extends StatefulWidget { // Classe InicialScreen que herda de StatefulWidget
  @override
  _InicialScreenState createState() => _InicialScreenState(); // Cria uma instância do estado para InicialScreen
}

class _InicialScreenState extends State<Menu> { // Classe privada que gerencia o estado da tela InicialScreen
  int _selectedIndex = 0; // Índice do item selecionado no Drawer

  @override
  Widget build(BuildContext context) { // Método build que retorna o widget da tela InicialScreen
    return Scaffold( // Scaffold: Widget responsável por criar um layout "padrão" para a tela
      appBar: AppBar( // AppBar: Barra localizada na parte superior da tela
        title: Text('Menu Principal'),
        // Título da AppBar
        backgroundColor: Color(0xFF7BA28F), // Cor de fundo da AppBar

      ),
      body: Stack( // Stack: Widget que permite empilhar múltiplos widgets
        children: [
          // Imagem de fundo
          Positioned.fill(
            child: Image(
              image: AssetImage('assets/logofosca.png'), // Caminho da imagem de fundo
              fit: BoxFit.cover, // Ajuste da imagem ao Stack
              color: Colors.black.withOpacity(0.1), // Cor da imagem com opacidade
              colorBlendMode: BlendMode.darken, // Modo de mesclagem de cores
            ),
          ),
        ],
      ),
      drawer: Drawer( // Drawer: Widget que cria um menu lateral
        child: ListView( // ListView: Widget que exibe uma lista de itens
          padding: EdgeInsets.zero, // Espaçamento zero para o ListView
          children: [
            const DrawerHeader( // Cabeçalho do Drawer
              decoration: BoxDecoration( // Estilização do cabeçalho
                color: Color(0xFF4D6659), // Cor de fundo do cabeçalho
              ),
              child: Text('Principal'), // Texto do cabeçalho
            ),
            ListTile( // Item da lista no Drawer
              title: const Text('Home'), // Título do item
              selected: _selectedIndex == 0, // Verifica se o item está selecionado
              onTap: () { // Ação ao tocar no item
                setState(() { // Atualiza o estado da tela
                  _selectedIndex = 0; // Define o índice do item selecionado
                });
                Navigator.pop(context); // Fecha o Drawer
              },
            ),
            ListTile( // Item da lista no Drawer
              title: const Text('Agendamento'), // Título do item
              selected: _selectedIndex == 1, // Verifica se o item está selecionado
              onTap: () { // Ação ao tocar no item
                setState(() { // Atualiza o estado da tela
                  _selectedIndex = 1; // Define o índice do item selecionado
                });
                Navigator.pop(context); // Fecha o Drawer
              },
            ),
            ListTile( // Item da lista no Drawer
              title: const Text('Cardapio'), // Título do item
              selected: _selectedIndex == 2, // Verifica se o item está selecionado
              onTap: () { // Ação ao tocar no item
                Navigator.push( // Navega para a tela de serviços
                  context,
                  MaterialPageRoute(builder: (context) => Principal()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}


