import 'package:flutter/material.dart'; // Importando o pacote material, que contém os widgets do Flutter

class Principal extends StatelessWidget { // Classe LoginScreen que herda de StatelessWidget
  @override
  Widget build(BuildContext context) { // Método build que retorna o widget da tela de login
    return MaterialApp( // MaterialApp: Widget que define as configurações gerais do app
      home: Scaffold( // Scaffold: Widget responsável por criar um layout "padrão" para a tela
        appBar: AppBar(
          title: Text('Cardápio'), // Título da AppBar
          backgroundColor: Color(0xFF4D6659), // Cor de fundo da AppBar
        ),
        body: Cardapio(), // Corpo da tela, definido pelo widget LoginBody
      ),
    );
  }
}

class Cardapio extends StatelessWidget {
  // Classe LoginBody que herda de StatelessWidget
  @override
  Widget build(BuildContext context) {
   return Container( // Container para os campos de entrada e botão
      padding: EdgeInsets.all(20.0), // Espaçamento interno
      decoration: BoxDecoration(
        color: Color(0xFF07BA28F), // Cor de fundo do Container
        borderRadius: BorderRadius.circular(10.0), // Bordas arredondadas
      ),
      child: Column(
       mainAxisAlignment: MainAxisAlignment.center,// Coluna que organiza os widgets verticalmente
        children: [
          Column(  /* Item 1 */
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(left: 35),
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/bolo1.png"),
                  ),
                ),
              ),
              Text("Céu de Morango - 32,00")
            ],
          ),
          Column( /* Item 2 */
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(left: 35),
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/bolo2.png"),
                  ),
                ),
              ),
              Text("Núvem de Canela - 35,90")
            ],
          ),
          Column( /* Item 2 */
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(left: 35),
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/bolo3.png"),
                  ),
                ),
              ),
              Text("Paraiso Silvestre - 37,00")
            ],
          ),
          Column( /* Item 2 */
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(left: 35),
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/bolo4.png"),
                  ),
                ),
              ),
              Text("Eclipse de Chocolate - 30,00")
            ],
          ),
          Column( /* Item 2 */
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(left: 35),
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/bolo5.png"),
                  ),
                ),
              ),
              Text("Estrelas de Morangos - 32,00")
            ],
          ),

        ],
      ),
    );
  }
}