import 'package:flutter/material.dart'; // Importando o pacote material, que contém os widgets do Flutter
import 'login.dart'; // Importando o arquivo login.dart

void main() => runApp(MyApp()); // Função principal que inicializa o app Flutter
class MyApp extends StatelessWidget { // Classe MyApp que herda de StatelessWidget
  @override
  Widget build(BuildContext context) { // Método build que retorna o widget principal do app
    return MaterialApp( // MaterialApp: Widget que define as configurações gerais do app
      theme: ThemeData( // Definindo o tema do app
        primarySwatch: Colors.pink, // Cor primária do tema
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: SplashScreen(), // Define a tela inicial como SplashScreen
      routes: { // Define as rotas para navegação entre telas
        '/login': (context) => login(), // Rota para a tela de login
      },
    );
  }
}

class SplashScreen extends StatefulWidget { // Classe SplashScreen que herda de StatefulWidget
  @override
  _SplashScreenState createState() => _SplashScreenState(); // Cria uma instância do estado para SplashScreen
}

class _SplashScreenState extends State<SplashScreen> { // Classe privada que gerencia o estado da tela SplashScreen
  @override
  void initState() { // Método chamado quando o estado é inicializado
    super.initState();
    // Simulando um carregamento por 5 segundos antes de redirecionar para a tela de login
    Future.delayed(Duration(seconds: 5), () {
      Navigator.pushReplacementNamed(context, '/login'); // Navega para a tela de login e substitui a tela atual
    });
  }

  @override
  Widget build(BuildContext context) { // Método build que retorna o widget da tela SplashScreen
    return Scaffold( // Scaffold: Widget responsável por criar um layout "padrão" para o app
      appBar: AppBar( // AppBar: Barra localizada na parte superior da tela
        title: Text('Delicious Cake'), // Título da AppBar
        backgroundColor: Color(0xFF7BA28F), // Cor de fundo da AppBar

      ),
      body: Container( // Container que envolve o conteúdo da tela
        decoration: BoxDecoration( // Estilização do Container
            image: DecorationImage( // Adicionando uma imagem de fundo ao Container
              image: AssetImage('assets/logo.png'), // Caminho da imagem de fundo
              fit: BoxFit.cover, // Ajuste da imagem ao Container
            ),
        ),
        child: Center( // Widget centralizado
          child: CircularProgressIndicator(), // Indicador de carregamento circular
        ),
      ),
    );
  }
}